package Drawing_MiljanaBogunovic_MH35_2017;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JComponent;
import java.awt.Graphics;

import elements.elements.Circle;
import elements.elements.Donut;
import elements.elements.Line;
import elements.elements.Point;
import elements.elements.Rectangle;
import elements.elements.Selected;

import java.awt.BorderLayout;
import javax.swing.JButton;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Iterator;
import java.util.LinkedList;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class frmDrw {

	private JFrame frame;
	private pnlDrawing pnl =new pnlDrawing(); //moja implementacija  
	boolean isOk = false,isOkB=false; // da znamo kad je covek kliknuo
	static LinkedList<Point> points = new LinkedList<Point>(); //malo dodajemo objekte u jednulistu
	static LinkedList<Rectangle> rectangles = new LinkedList<Rectangle>();
	static LinkedList<Circle> circles = new LinkedList<Circle>();
	static LinkedList<Line> lines = new LinkedList<Line>();
	static LinkedList<Donut> donuts = new LinkedList<Donut>();
	private int x,y,x1,y1, xC, yC, xL, yL;
	boolean selC,selP,selL,selR,selD;
	private Color colorP , colorR , colorC , colorL , colorD;
	private Color colorRF, colorCF, colorDF;
	Circle c,c1;
	Line l,l1;
	Point Pp,Pp1;
	Donut d,d1;
	Rectangle r,r1;
	int i;
	
	Object obj;
	Graphics graphics = pnl.getGraphics();
	Selected o;
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frmDrw window = new frmDrw();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public frmDrw() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 900, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//JPanel pnlZaCrtanje = new JPanel();
		pnl.setBackground(Color.WHITE);
		frame.getContentPane().add(pnl, BorderLayout.CENTER); // dodavanje pnl iz pnlDrawing u nas frejm
		
		pnl.addMouseListener(new MouseAdapter() {
			
			public void mouseClicked(MouseEvent e) {
			
				x = e.getX();
				y = e.getY();
				System.out.println(x);
				System.out.println(y);
			}
		});
		
		JPanel pnlDugmici = new JPanel();
		frame.getContentPane().add(pnlDugmici, BorderLayout.SOUTH);
		
		JButton btnKrug = new JButton("Krug");
		btnKrug.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dlgCircle dc = new dlgCircle();
				dc.setVisible(true);
				if(dc.isOk ==true) {
					Circle c1 = new Circle();
					int flag = 0;
					//Point pointC = new Point(x,y);
					//xC = pointC.getX();
					//yC = pointC.getY();
					try {
						c1 = new Circle(new Point(x,y),
								Integer.parseInt(dc.getTxtBoja().getText().toString()));
						//provera sta je uneseno
						
					}catch(Exception ex) {
						flag = 1;
						JOptionPane.showMessageDialog(null, "Ne mozete uneti string za vrednosti");
						
					}
					if(c1.getR() < 0 ) {
						JOptionPane.showMessageDialog(null, "Da bi dodali objekat morate da unesete pozitivne duzine!");
						dc.dispose();				
					}
					else {
						if(flag == 0) {
							colorC = dc.color; //boja kruga u ovoj klasi koju cemo setovati da nam bude boja kruga iz klase krug
							colorCF = dc.colorF; //ZA OVO ME ZOVITE DA VAM OPET OBJASNIM
							c1.setColor(colorC);
							if(colorCF != null) {
								c1.setFill(true);
								c1.setColorFill(colorCF);
							}
							circles.add(c1);
							selC = false; //promenljiva koja nam se menja jedino pri selekciji objekta
							pnl.repaint(); //poziva se da bi se iscrtao objekat
					}
						
					}
				}
			}
		});
		pnlDugmici.add(btnKrug);
		
		JButton btnTacka = new JButton("Tacka");
		
			btnTacka.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				isOk=true;
				dlgPoint dp = new dlgPoint();
				dp.setVisible(true);
				if(dp.isOk) {
					
					colorP = dp.getColor();
					Point p1 = new Point();
					p1.setX(x);
					p1.setY(y);
					p1.setColor(colorP);
					points.add(p1);
					selP =false; 
					pnl.repaint();	
					
				}
			}
		});
			
		pnlDugmici.add(btnTacka);
		
		JButton btnLinija = new JButton("Linija");
		btnLinija.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dlgLine dl = new dlgLine();
				dl.setVisible(true);
				if(dl.isOk) {
				//xL = dl.getX();
				//yL = dl.getY();
				colorL = dl.color;
				Line l1 = new Line();
					
				int flag = 0;
				try {
					l1 = new Line(new Point(x,y),
							new Point(Integer.parseInt(dl.getTxtX().getText().toString()),Integer.parseInt(dl.getTxtY().getText().toString())));
					
					
				}catch(Exception ex) {
					flag = 1;
					JOptionPane.showMessageDialog(null, "Ne mozete uneti string za vrednosti");
					
				}
				if(l1.getEndPoint().getX() < 0 || l1.getEndPoint().getY() < 0) {
					JOptionPane.showMessageDialog(null, "Da bi dodali objekat morate da unesete pozitivne duzine!");
					dl.dispose();				
				}
				else {
					if(flag == 0) {
						l1.setColor(colorL);
						lines.add(l1);
						selL = false;
						pnl.repaint();
				}
				
				}
				}
				
			}
		});
		pnlDugmici.add(btnLinija);
		
		JButton btnKrofna = new JButton("Krofna");
		btnKrofna.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dlgDonut dd = new dlgDonut();
				dd.setVisible(true);
				if(dd.isOk) {
					Donut d1 = new Donut();
					int flag = 0;
					try {
						d1 = new Donut(new Point(x,y),
								Integer.parseInt(dd.getTxtOutR().getText().toString()),Integer.parseInt(dd.getTxtInnR().getText().toString()));
						
						
					}catch(Exception ex) {
						flag = 1;
						JOptionPane.showMessageDialog(null, "Ne mozete uneti string za vrednosti");
						
					}
					if(d1.getR() < 0 || d1.getInnerR() < 0) {
						JOptionPane.showMessageDialog(null, "Da bi dodali objekat morate da unesete pozitivne duzine!");
						dd.dispose();				
					}
					//if(Integer.parseInt(dd.getTxtInnR().toString()) >= Integer.parseInt(dd.getTxtOutR().toString())) {
					//	JOptionPane.showMessageDialog(null, "Unutrasnji precnik mora da bude manji od spoljasnjeg!");
						
					//}
					else {
						if(flag == 0) {
							colorDF = dd.colorF;
							colorD = dd.color;
							d1.setColor(colorD);
							if(colorDF != null) {
								d1.setFill(true);
								d1.setColorFill(colorDF);
							}
							selD = false;
							donuts.add(d1);
							pnl.repaint();
							
					}
						
					}
				}
			}
		});
		pnlDugmici.add(btnKrofna);
		
		JButton btnPrvougao = new JButton("Pravougaonik");
		btnPrvougao.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dlgRectangle dr = new dlgRectangle();
				dr.setVisible(true);
				if(dr.isOk) {
					
					Rectangle r1 = new Rectangle();
						
					int flag = 0;
					try {
						r1 = new Rectangle(new Point(x,y),
								Integer.parseInt(dr.getTxtHeight().getText().toString()),Integer.parseInt(dr.getTxtWidth().getText().toString()));
						
						
					}catch(Exception ex) {
						flag = 1;
						JOptionPane.showMessageDialog(null, "Ne mozete uneti string za vrednosti");
						
					}
					if(r1.getHeight() < 0 || r1.getWidth() < 0) {
						JOptionPane.showMessageDialog(null, "Da bi dodali objekat morate da unesete pozitivne duzine!");
						dr.dispose();				
					}
					else {
						if(flag == 0) {
							colorR = dr.color;
							colorRF = dr.colorF;
							r1.setColor(colorR);
							if(colorRF != null) {
								r1.setFill(true);
								r1.setColorFill(colorRF);
							}
							
							selR = false; 
							rectangles.add(r1);
							pnl.repaint();
					}
						
					}
				}
			}
		});
		pnlDugmici.add(btnPrvougao);
		
		JPanel pnlOpcije = new JPanel();
		frame.getContentPane().add(pnlOpcije, BorderLayout.EAST);
		GridBagLayout gbl_pnlOpcije = new GridBagLayout();
		gbl_pnlOpcije.columnWidths = new int[]{0, 0};
		gbl_pnlOpcije.rowHeights = new int[]{0, 0, 0, 0, 0, 0};
		gbl_pnlOpcije.columnWeights = new double[]{0.0, Double.MIN_VALUE};
		gbl_pnlOpcije.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		pnlOpcije.setLayout(gbl_pnlOpcije);
		
		JButton btnSelektuj = new JButton("Selektuj");
		btnSelektuj.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(points.isEmpty() && circles.isEmpty() && rectangles.isEmpty() && lines.isEmpty() && donuts.isEmpty()) {
					JOptionPane.showMessageDialog(null, "Nijedan element nije iscrtan!");
				}
				else {
					pnl.addMouseListener(new MouseAdapter() {
						public void mouseClicked(MouseEvent e) {
							
							x1 = e.getX();
							y1 = e.getY();
							System.out.println(x1);
							System.out.println(y1);
							Point p = new Point(x1,y1); //tacka koja se sadrzi u krugu
							
							if(selC == false) {
								c = new Circle();
								Iterator<Circle> it = circles.iterator();
								while(it.hasNext()) {
									c = it.next();
									c.setSelected(false);
									if(c.contains(p)) {
										c.setSelected(true);
										selC = true;
										pnl.repaint();
										
									}
								}
							}
							if(selP == false) {
								Pp = new Point();
								Iterator<Point> itP = points.iterator();
								while(itP.hasNext()) {
									Pp = itP.next();
									Pp.setSelected(false);
									if(Pp.contains(p.getX(),p.getY())) {
										Pp.setSelected(true);
										selP = true;
										pnl.repaint();
									}
								}
							}
							if(selR == false) {
								r = new Rectangle();
								Iterator<Rectangle> itR = rectangles.iterator();
								while(itR.hasNext()) {
									r = itR.next();
									r.setSelected(false);
									if(r.contains(p)) {
										r.setSelected(true);
										selR = true;
										pnl.repaint();
									}
								}
							}
							if(selL == false) {
								l = new Line();
								Iterator<Line> itL = lines.iterator();
								while(itL.hasNext()) {
									l = itL.next();
									l.setSelected(false);
									if(l.contains(x1, y1)) {
										l.setSelected(true);
										selL = true;
										pnl.repaint();
									}
								}
							}
							if(selD == false) {
								d = new Donut();
								Iterator<Donut> itD = donuts.iterator();
								while(itD.hasNext()) {
									d = itD.next();
									d.setSelected(false);
									if(d.contains(p.getX(),p.getY())) {
										d.setSelected(true);
										selD = true;
										pnl.repaint();
									}
								}
							}
						
						}
					
					});
				}
			}
		});
		GridBagConstraints gbc_btnSelektuj = new GridBagConstraints();
		gbc_btnSelektuj.insets = new Insets(0, 0, 5, 0);
		gbc_btnSelektuj.gridx = 0;
		gbc_btnSelektuj.gridy = 0;
		pnlOpcije.add(btnSelektuj, gbc_btnSelektuj);
		
		JButton btnObrisi = new JButton("Obrisi");
		btnObrisi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(selL == false && selR == false && selP == false && selD ==false && selC == false) {
					JOptionPane.showMessageDialog(null, "Radnju je nemoguce izvrsiti bez prethodno selektovanog objekta");
				}
				if(rectangles.isEmpty() && points.isEmpty() && donuts.isEmpty() && lines.isEmpty() && circles.isEmpty()) {
					JOptionPane.showMessageDialog(null, "Morate prvo da dodate objekte!");
				}
				else {
					if(selC == true) {
						Delete(c);
					}
					if(selP == true) {
						Delete(Pp);
					}
					if(selL == true) {
						Delete(l);
					}
					if(selD == true) {
						Delete(d);
					}
					if(selR == true) {
						Delete(r);
					}
				}
			}
		});
		GridBagConstraints gbc_btnObrisi = new GridBagConstraints();
		gbc_btnObrisi.insets = new Insets(0, 0, 5, 0);
		gbc_btnObrisi.gridx = 0;
		gbc_btnObrisi.gridy = 3;
		pnlOpcije.add(btnObrisi, gbc_btnObrisi);
		
		JButton btnModifikuj = new JButton("Modifikuj");
		btnModifikuj.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(selL == false && selR == false && selP == false && selD ==false && selC == false) {
					JOptionPane.showMessageDialog(null, "Radnju je nemoguce izvrsiti bez prethodno selektovanog objekta");
				}
				if(rectangles.isEmpty() && points.isEmpty() && donuts.isEmpty() && lines.isEmpty() && circles.isEmpty()) {
					JOptionPane.showMessageDialog(null, "Morate prvo da dodate objekte!");
				}
				if(selL == true) {
					Modificate(l);
				}
				if(selC == true) {
					Modificate(c);
					
				}
				if(selR) {
					Modificate(r);
				}
				
				if(selP) {
					Modificate(Pp);
				}
				if(selD) {
					Modificate(d);
				}
				
				
			}
		});
		GridBagConstraints gbc_btnModifikuj = new GridBagConstraints();
		gbc_btnModifikuj.gridx = 0;
		gbc_btnModifikuj.gridy = 4;
		pnlOpcije.add(btnModifikuj, gbc_btnModifikuj);
		
		
	}
	
	public void Delete(Circle c) {
		if(c.isSelected() == true) {

			c.setSelected(false);
			dlgCircle dc = new dlgCircle();
			dc.getTxtBoja().setText(Integer.toString(c.getR())); 
			dc.btnBojaF.setBackground(c.getColorF());
			dc.btnBojaIvice.setBackground(c.getColor());
			
			dc.setVisible(true);
			circles.remove(c);
			pnl.repaint();
		
		}
	}
	public void Delete(Line l) {
		if(l.isSelected() == true) {
			l.setSelected(false);
			dlgLine dl =  new dlgLine();
			dl.getTxtX().setText(Integer.toString(l.getEndPoint().getX()));
			dl.getTxtY().setText(Integer.toString(l.getEndPoint().getY()));
			dl.btnBoja.setBackground(l.getColor());
			
			dl.setVisible(true);
			dl.setModal(true);
			
			lines.remove(l);
			pnl.repaint();
			
		}
	}
	public void Delete(Rectangle r) {
		if(r.isSelected() == true) {
			r.setSelected(false);
			dlgRectangle dr = new dlgRectangle();
			dr.getTxtHeight().setText(Integer.toString(r.getHeight()));
			dr.getTxtWidth().setText(Integer.toString(r.getWidth()));
			dr.btnBoja.setBackground(r.getColor());
			dr.btnBojaF.setBackground(r.getColorF());
			
			dr.setVisible(true);
			
			rectangles.remove(r);
			pnl.repaint();
		}
	}
	public void Delete(Donut d) {
		if(d.isSelected() == true) {
			d.setSelected(false);
			dlgDonut dd = new dlgDonut();
			dd.getTxtInnR().setText(Integer.toString(d.getInnerR()));
			dd.getTxtOutR().setText(Integer.toString(d.getR()));
			dd.btnBoja.setBackground(d.getColor());
			dd.btnBojaF.setBackground(d.getColorF());
			dd.setVisible(true);
			donuts.remove(d);
			pnl.repaint();
		}
	}
	public void Delete(Point Pp) {
		if(Pp.isSelected() == true) {
			Pp.setSelected(false);
			dlgPoint dp = new dlgPoint();
			dp.btnBoja.setBackground(Pp.getColor());
			dp.setVisible(true);
			points.remove(Pp);
			pnl.repaint();
		}
	}
	
	public void Modificate(Point Pp) {
		if(Pp.isSelected()==true) {
			Pp1 = new Point();
			dlgPoint dp = new dlgPoint();
			dp.setVisible(true);
			dp.setModal(true);
			
			
			
			
			
		}
		
		
	}
	
	
	public void Modificate(Line l) {
		//dodaj proveru da li je string unet preko try catch i dodaj neku bool
		if(l.isSelected()==true) {
			dlgLine dl = new dlgLine();
		
			dl.getTxtX().setText(Integer.toString(l.getEndPoint().getX()));;
			dl.getTxtY().setText(Integer.toString(l.getEndPoint().getY()));
			dl.btnBoja.setBackground(l.getColor());

			dl.color = l.getColor();
			dl.setVisible(true);
		
			int flag = 0;
			try {
				l.setEndPoint(new Point(Integer.parseInt(dl.getTxtX().getText()),Integer.parseInt(dl.getTxtY().getText())));
				}catch(Exception ex) {
					flag = 1;
					JOptionPane.showMessageDialog(null, "Ne mozete uneti string za vrednosti");
					
				}
			if(l.getEndPoint().getX() < 0 || l.getEndPoint().getY() < 0) {
				JOptionPane.showMessageDialog(null, "Da bi dodali objekat morate da unesete pozitivne duzine!");
				dl.dispose();				
				}
			else {
				if(flag == 0) {
					l.setColor(dl.color);
					l.setSelected(false);
					selL = false;
					pnl.repaint();
				}
				
				}
				
			}
			
	}
	
	public void Modificate(Circle c) {
		if(c.isSelected() == true) {
			dlgCircle dc = new dlgCircle();
			
			dc.getTxtBoja().setText(Integer.toString(c.getR()));
			dc.btnBojaIvice.setBackground(c.getColor());
			dc.color = c.getColor();
			dc.colorF = c.getColorF();
			dc.btnBojaF.setBackground(c.getColorF());
			dc.setVisible(true);
			dc.setModal(true);
				int r = Integer.parseInt(dc.getTxtBoja().getText().toString());
				try {
				c.setR(r);
				} catch(Exception e) {
					JOptionPane.showMessageDialog(null, "Ne moze biti negativan poluprecnik");
				}
				c.setColor(dc.color);
				c.setFill(true);
				c.setColorFill(dc.colorF);
				selC = false;
				c.setSelected(false);
				pnl.repaint();
				
			}
		
	}
	
	public void Modificate(Rectangle r) {
		if(r.isSelected() == true) {
			dlgRectangle dr =  new dlgRectangle();
			dr.getTxtHeight().setText(Integer.toString(r.getHeight()));
			dr.getTxtWidth().setText(Integer.toString(r.getWidth()));
			dr.btnBoja.setBackground(r.getColor());
			dr.btnBojaF.setBackground(r.getColorF());
			dr.color = r.getColor();
			dr.colorF = r.getColorF();
			
			dr.setVisible(true);
			dr.setModal(true);
			int flag =0;
			try {
				r.setHeight(Integer.parseInt(dr.getTxtHeight().getText()));
				r.setWidth(Integer.parseInt(dr.getTxtWidth().getText()));
			}catch(Exception e) {
				flag =1;
				JOptionPane.showMessageDialog(null, "Ne mozete postaviti negativne vrednosti");
			}
			if(flag == 0) {
				r.setColor(dr.color);
				r.setFill(true);
				r.setColorFill(dr.colorF);
				selR = false;
				r.setSelected(false);
		
				pnl.repaint();
			}
		}
	}

	


}
